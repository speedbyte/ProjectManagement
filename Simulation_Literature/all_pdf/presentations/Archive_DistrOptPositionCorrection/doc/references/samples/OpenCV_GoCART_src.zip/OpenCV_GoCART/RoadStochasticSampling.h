#pragma once

class CRoadStochasticSampling
{
public:
	CRoadStochasticSampling(void);
	~CRoadStochasticSampling(void);
};
