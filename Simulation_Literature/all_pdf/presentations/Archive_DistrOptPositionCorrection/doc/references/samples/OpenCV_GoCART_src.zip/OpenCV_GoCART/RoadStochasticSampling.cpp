#include ".\roadstochasticsampling.h"

CRoadStochasticSampling::CRoadStochasticSampling(void)
{
}

CRoadStochasticSampling::~CRoadStochasticSampling(void)
{
}
