if exist('vid')
  delete(vid);
end
if exist('sapi')
  sapi.delete;
end
clear all;
close all;
disp 'all vars cleared';

